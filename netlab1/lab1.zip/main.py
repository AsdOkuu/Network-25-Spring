
import lab
#import answer as lab

def main():
    print(lab.Q1())
    print(lab.Q2())
    print(lab.Q3())
    print(lab.Q4())
    print(lab.Q5())
    print(lab.Q6())
    print(lab.Q7())


if __name__=='__main__':
    main()